/***************************************
  $Header$

  Header file for lujvo canonicalisation function.
  ***************************************/

/* COPYRIGHT */

#ifndef CANONLUJ_H
#define CANONLUJ_H    /*+ To stop multiple inclusions. +*/

extern char *canon_lujvo (char *x);

#endif /* CANONLUJ_H */
