/***************************************
  $Header$

  ***************************************/

/* COPYRIGHT */

#ifndef STAG_DFA_H
#define STAG_DFA_H
extern int stag_exitval[];
extern int stag_next_state(int, int);
#endif

