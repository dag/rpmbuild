/***************************************
  $Header$

  Low level dictionary routines header
  ***************************************/

/* COPYRIGHT */

#ifndef DICTACCS_H
#define DICTACCS_H

extern char * dict_lookup(char *key);

#endif /* DICTACCS_H */

